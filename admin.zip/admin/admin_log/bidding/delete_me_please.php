<div class="row">
    <div class="col-md-5 position-relative ">
            </br>
            <textarea name="NAI" id="answer"class="form-control" rows="1" disabled>Ahasan</textarea>
    </div> 
    
    <div class="col-md-5 position-relative "></br>
         <textarea name="NAI" id="answer"  class="form-control" rows="1" disabled>Habinb</textarea>
    </div>
    
    <div class="col-md-2 position-relative ">
        
        <button class="btn btn-danger deletebtn" row="'+i+'" name="add_ans" type = "button" id="add_ans"><i class="fa fa-trash "></i></button>
        
    </div>
 </div>