<?php
	$dbname = "bdabashon_bidding";
	$hostname = "localhost";
	$username = "bdabashon_bidding";
	$password = "bdabashon_bidding";
	$con = mysqli_connect($hostname, $username, $password, $dbname );
	mysqli_set_charset($con, "utf8");
?>
