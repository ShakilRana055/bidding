
                <div class="scrollbar-sidebar">
                    <div class="app-sidebar__inner">
                        <ul class="vertical-nav-menu">
                            <li class="app-sidebar__heading">Menu</li>
                            <li
                                 class="mm-active">
                                <a href="#">
                                    <i class="metismenu-icon pe-7s-rocket"></i>
                                    Dashboards
                                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                                </a>
                                <ul>
                                   
                                    
                                    <li>
                                        <a href="?pagex=bidding&&root=bidding">
                                            <i class="metismenu-icon">
                                            </i>Bidding
                                        </a>
                                    </li>
                                    <li>
                                        <a href="?pagex=user_buy_share&&root=shares">
                                            <i class="metismenu-icon">
                                            </i>Shares
                                        </a>
                                    </li>
                                    <li>
                                        <a href="?pagex=user_share_profile&&root=shares">
                                            <i class="metismenu-icon">
                                            </i>My Shares
                                        </a>
                                    </li>
                                    
                                    <li>
                                        <a href="?pagex=userMyWallet&&root=member">
                                            <i class="metismenu-icon">
                                            </i>My Wallet
                                        </a>
                                    </li>
                                    
                                    <li>
                                        <a href="?pagex=user_currency&&root=currency">
                                            <i class="metismenu-icon">
                                            </i>Currency
                                        </a>
                                    </li>
                                    <li>
                                        <a href="?pagex=lottery&&root=lottery">
                                            <i class="metismenu-icon">
                                            </i>Lottery
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="metismenu-icon">
                                            </i>Freelancer
                                            <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                                        </a>
                                        <ul>
                                            <li>
                                                <a href="?pagex=freelancer_data_entry&&root=freelancer">
                                                    <i class="metismenu-icon">
                                                    </i>Data Entry
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    
                                </ul>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="metismenu-icon pe-7s-browser"></i>
                                    Setting
                                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                                </a>
                                <ul>
                                    <li>
                                        <a href="logout.php">
                                            <i class="metismenu-icon"></i>
                                            Logout
                                        </a>
                                    </li>
                                    
                                    <li>
                                        <a href="?pagex=view_profile&&root=member">
                                            <i class="metismenu-icon">
                                            </i>view profile
                                        </a>
                                    </li>
                                    
                                </ul>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </div>    
            
            <div class="app-main__outer">
                <div class="app-main__inner">
                <div class="app-container app-theme-white body-tabs-shadow">
                    
                    <script type="text/javascript" src="assets/scripts/main.cba69814a806ecc7945a.js"></script>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>