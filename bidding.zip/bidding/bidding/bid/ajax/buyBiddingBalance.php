<?php session_start();?>
<?php
    
    if( isset( $_POST[ 'saveIt' ] ) )
    {
        include( "../config/db_connection.php") ;
        $totalCost = $_POST['totalCost'] ;
        $totalBiddingCost = $_POST['totalBiddingCost'] ;
        $cuurentBalance = $_POST['cuurentBalance'] ;
        $id = $_SESSION['user']['USER_REGISTRATION_NO'] ;
        $final = doubleval( $cuurentBalance ) - doubleval( $totalCost ) ;
        $dateTime = date( "Y-m-d h:i:s" ) ;
        
        $query = "INSERT INTO user_master_accounts SET `USER_REGISTRATION_NO` = '$id', `TRANSACTION_AMOUNT` = '$totalCost', 
        `BIDDING_BALANCE` = '$totalBiddingCost', `TRANSACTION_TYPE_NO` = '-1', `TRANSACTION_ON` = '$dateTime', `CREATED_ON` = '$dateTime'";
        
        $result = mysqli_query ( $con , $query ) ;
        if( $result )
        {
            echo 1 ;
        }
        else
        {
            echo 0 ;
        }
    }
    ?>